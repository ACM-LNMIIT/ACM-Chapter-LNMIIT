import { motion } from "motion/react";
import { teamMembers } from "../../assets/assets.js";
import { EvervaultCard } from "../ui/evervault-card.jsx";

const TeamSection = () => {
	return (
		<div className="w-full bg-gradient-to-b from-[#020B05] to-[#1F2321] dark:bg-gradient-to-b dark:from-[#e8e9cd] dark:to-[#fbfbd3] py-16 px-4 sm:px-6 lg:px-10">
			<div className="max-w-7xl mx-auto">
				{/* Header */}
				<motion.div
					initial={{ opacity: 0, y: 20 }}
					animate={{ opacity: 1, y: 0 }}
					transition={{ duration: 0.5 }}
					className="text-center mb-12">
					<h2 className="text-4xl sm:text-5xl font-bold mb-3 bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">
						Meet Our Team
					</h2>
					<p className="text-gray-400 dark:text-gray-600 text-lg">
						Passionate individuals driving innovation and excellence
					</p>
				</motion.div>

				{/* Team Grid */}
				<motion.div
					initial={{ opacity: 0 }}
					animate={{ opacity: 1 }}
					transition={{ duration: 0.6, delay: 0.1 }}
					className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
					{teamMembers.map((member, idx) => (
						<motion.div
							key={member._id}
							initial={{ opacity: 0, y: 20 }}
							animate={{ opacity: 1, y: 0 }}
							transition={{ duration: 0.5, delay: idx * 0.1 }}
							whileHover={{ scale: 1.05 }}
							className="p-0.5 rounded-xl bg-gradient-to-b from-[rgba(49,151,102,0.3)] to-[rgba(244,190,0,0.5)]">
							<div className="rounded-xl bg-gradient-to-b from-[#1F2321] to-[#020B05] dark:bg-gradient-to-b dark:from-[#fbfbd3] dark:to-[#f0e9ba]">
								<EvervaultCard className="w-full h-[350px] dark:bg-gradient-to-b dark:from-[#fbfbd3] dark:to-[#f0e9ba]">
									<div className="flex flex-col gap-0 rounded-xl overflow-hidden cursor-pointer hover:translate-y-[-10px] transition-all duration-500 h-full">
										{/* Image */}
										<div className="flex-1 overflow-hidden">
											<img
												className="w-full h-full object-cover"
												src={member.image}
												alt={member.name}
											/>
										</div>

										{/* Info Section */}
										<div className="p-4 bg-gradient-to-b from-[#1F2321] to-[#020B05] dark:bg-gradient-to-b dark:from-[#fbfbd3] dark:to-[#f0e9ba]">
											{/* Tech Stack */}
											<div className="flex flex-wrap gap-2 mb-3">
												{member.techStack.map((badge, idx) => (
													<span
														key={idx}
														className="bg-green-500/20 dark:bg-green-700/20 text-green-400 dark:text-green-600 text-xs px-2 py-1 rounded-full font-semibold">
														{badge}
													</span>
												))}
											</div>

											{/* Name */}
											<p className="text-lg font-bold text-white dark:text-[#020B05] mb-1">
												{member.name}
											</p>

											{/* Designation */}
											<p className="text-sm text-gray-400 dark:text-gray-600 font-medium">
												{member.designation}
											</p>
										</div>
									</div>
								</EvervaultCard>
							</div>
						</motion.div>
					))}
				</motion.div>

				{/* View Full Team Button */}
				<motion.div
					initial={{ opacity: 0, y: 20 }}
					animate={{ opacity: 1, y: 0 }}
					transition={{ duration: 0.5, delay: 0.4 }}
					className="flex justify-center">
					<a
						href="/team"
						className="px-8 py-3 bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white font-bold rounded-lg transition-all transform hover:scale-105">
						View Full Team
					</a>
				</motion.div>
			</div>
		</div>
	);
};

export default TeamSection;
