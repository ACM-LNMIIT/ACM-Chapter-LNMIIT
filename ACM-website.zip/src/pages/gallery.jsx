import { motion } from "motion/react";
import { useState } from "react";

const Gallery = () => {
	const [selectedCategory, setSelectedCategory] = useState("all");

	const galleryItems = [
		{
			id: 1,
			category: "events",
			title: "Tech Conference 2024",
			image: "[IMAGE_PLACEHOLDER_1]"
		},
		{
			id: 2,
			category: "workshops",
			title: "Web Development Workshop",
			image: "[IMAGE_PLACEHOLDER_2]"
		},
		{
			id: 3,
			category: "hackathon",
			title: "Annual Hackathon",
			image: "[IMAGE_PLACEHOLDER_3]"
		},
		{
			id: 4,
			category: "events",
			title: "Networking Event",
			image: "[IMAGE_PLACEHOLDER_4]"
		},
		{
			id: 5,
			category: "workshops",
			title: "AI & Machine Learning",
			image: "[IMAGE_PLACEHOLDER_5]"
		},
		{
			id: 6,
			category: "hackathon",
			title: "Hackathon Finals",
			image: "[IMAGE_PLACEHOLDER_6]"
		},
		{
			id: 7,
			category: "events",
			title: "Career Fair",
			image: "[IMAGE_PLACEHOLDER_7]"
		},
		{
			id: 8,
			category: "workshops",
			title: "Cloud Computing Basics",
			image: "[IMAGE_PLACEHOLDER_8]"
		}
	];

	const categories = ["all", "events", "workshops", "hackathon"];

	const filteredItems = selectedCategory === "all"
		? galleryItems
		: galleryItems.filter(item => item.category === selectedCategory);

	return (
		<div className="min-h-screen dark:bg-[#e8e9cd] bg-[#020B05] text-white dark:text-gray-900 py-20 px-4">
			<div className="max-w-7xl mx-auto">
				{/* Header */}
				<motion.div
					initial={{ opacity: 0, y: 20 }}
					animate={{ opacity: 1, y: 0 }}
					transition={{ duration: 0.5 }}
					className="text-center mb-16">
					<h1 className="text-5xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">
						Photo Gallery
					</h1>
					<p className="text-xl text-gray-400 dark:text-gray-600">
						Moments from our events and activities
					</p>
				</motion.div>

				{/* Category Filter */}
				<motion.div
					initial={{ opacity: 0, y: 10 }}
					animate={{ opacity: 1, y: 0 }}
					transition={{ duration: 0.5, delay: 0.1 }}
					className="flex flex-wrap justify-center gap-4 mb-12">
					{categories.map((cat) => (
						<button
							key={cat}
							onClick={() => setSelectedCategory(cat)}
							className={`px-6 py-2 rounded-full font-semibold transition-all capitalize ${
								selectedCategory === cat
									? "bg-gradient-to-r from-green-500 to-blue-500 text-white"
									: "bg-gray-800 dark:bg-gray-200 text-gray-300 dark:text-gray-700 hover:bg-gray-700 dark:hover:bg-gray-300"
							}`}>
							{cat}
						</button>
					))}
				</motion.div>

				{/* Gallery Grid */}
				<motion.div
					layout
					className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
					{filteredItems.map((item, idx) => (
						<motion.div
							key={item.id}
							initial={{ opacity: 0, scale: 0.9 }}
							animate={{ opacity: 1, scale: 1 }}
							transition={{ duration: 0.3, delay: idx * 0.05 }}
							whileHover={{ scale: 1.05 }}
							className="group relative overflow-hidden rounded-lg bg-gray-800 dark:bg-gray-200 aspect-square cursor-pointer">
							{/* Image Placeholder */}
							<div className="w-full h-full bg-gradient-to-br from-green-500/20 to-blue-500/20 dark:from-green-700/20 dark:to-blue-700/20 flex items-center justify-center">
								<div className="text-center">
									<div className="text-4xl mb-2">📷</div>
									<p className="text-sm text-gray-400 dark:text-gray-600">
										{item.image}
									</p>
								</div>
							</div>

							{/* Overlay */}
							<div className="absolute inset-0 bg-black/60 dark:bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
								<div>
									<h3 className="text-lg font-bold text-white">{item.title}</h3>
									<p className="text-sm text-gray-300 capitalize">{item.category}</p>
								</div>
							</div>
						</motion.div>
					))}
				</motion.div>

				{/* Empty State */}
				{filteredItems.length === 0 && (
					<motion.div
						initial={{ opacity: 0 }}
						animate={{ opacity: 1 }}
						className="text-center py-12">
						<p className="text-xl text-gray-400 dark:text-gray-600">
							No images found in this category
						</p>
					</motion.div>
				)}
			</div>
		</div>
	);
};

export default Gallery;
